l'histoire du codeur fou
