# Exercice-Cadavre-Exquis-SebastienC
Cadavre Exquis

**L'histoire de l'histoire**

Mourant, allongé sur le lit dans sa chambre, un vieillard distingue une merveilleuse odeur de tarte aux pommes provenant de la cuisine...
Il demanda a son petit fils : "Petit, va donc me chercher une part de tarte aux pommes, elle sent tellement bon, ce serai certainement un de mes derniers plaisir avant de mourir... "
